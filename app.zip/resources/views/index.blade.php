@extends('layouts.admin') <!-- assuming you created this layout -->

@section('content')
    <h1>All Patients</h1>
@endsection
