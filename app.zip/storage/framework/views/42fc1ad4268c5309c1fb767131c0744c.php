

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Edit Lab Test</h2>

    <form action="<?php echo e(route('admin.lab-tests.update', $labTest->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($labTest->name); ?>" required>
        </div>

        <div class="mb-3">
            <label>Category</label>
            <input type="text" name="category" class="form-control" value="<?php echo e($labTest->category); ?>">
        </div>

        <div class="mb-3">
            <label>Price (₹)</label>
            <input type="number" step="0.01" name="price" class="form-control" value="<?php echo e($labTest->price); ?>">
        </div>
        
         <div class="mb-3">
            <label>Turnaround_time</label>
            <input type="number" step="0.01" name="price" class="form-control" value="<?php echo e($labTest->price); ?>">
        </div>

        
        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control" rows="3"><?php echo e($labTest->description); ?></textarea>
        </div>

        <div class="mb-3">
            <label>Test_requirements</label>
            <input type="number" step="0.01" name="price" class="form-control" value="<?php echo e($labTest->price); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="<?php echo e(route('admin.lab-tests.index')); ?>" class="btn btn-secondary">Back</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP\hospital-lab-system\resources\views/admin/lab_tests/edit.blade.php ENDPATH**/ ?>