

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="bg-white rounded-lg shadow-sm border border-blue-100 overflow-hidden">
        <!-- Form Header -->
        <div class="px-6 py-4 border-b border-blue-100 bg-blue-50">
            <h2 class="text-xl font-semibold text-blue-600">Add New Lab Test</h2>
            <p class="text-sm text-blue-500 mt-1">Fill in the details below to create a new lab test</p>
        </div>

        <!-- Form Content -->
        <form action="<?php echo e(route('admin.lab-tests.store')); ?>" method="POST" class="p-6">
            <?php echo csrf_field(); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Name Field -->
                <div class="space-y-2">
                    <label class="block text-sm font-medium text-blue-600">Test Name *</label>
                    <input type="text" name="name" class="block w-full rounded-md border-blue-200 shadow-sm focus:border-blue-500 focus:ring-blue-500" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Category Field -->
                <div class="space-y-2">
                    <label class="block text-sm font-medium text-blue-600">Category</label>
                    <select name="category" class="block w-full rounded-md border-blue-200 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select Category</option>
                        <option value="Hematology">Hematology</option>
                        <option value="Biochemistry">Biochemistry</option>
                        <option value="Microbiology">Microbiology</option>
                        <option value="Pathology">Pathology</option>
                        <option value="Radiology">Radiology</option>
                    </select>
                </div>

                <!-- Price Field -->
                <div class="space-y-2">
                    <label class="block text-sm font-medium text-blue-600">Price (₹) *</label>
                    <div class="relative rounded-md shadow-sm">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <span class="text-gray-500 sm:text-sm">₹</span>
                        </div>
                        <input type="number" step="0.01" min="0" name="price" class="block w-full pl-8 rounded-md border-blue-200 focus:border-blue-500 focus:ring-blue-500" required>
                    </div>
                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Turnaround Time -->
                <div class="space-y-2">
                    <label class="block text-sm font-medium text-blue-600">Turnaround Time</label>
                    <div class="relative rounded-md shadow-sm">
                        <input type="text" name="turnaround_time" class="block w-full rounded-md border-blue-200 shadow-sm focus:border-blue-500 focus:ring-blue-500" placeholder="e.g. 24-48 hours">
                    </div>
                </div>

                <!-- Description Field -->
                <div class="space-y-2 md:col-span-2">
                    <label class="block text-sm font-medium text-blue-600">Description</label>
                    <textarea name="description" rows="3" class="block w-full rounded-md border-blue-200 shadow-sm focus:border-blue-500 focus:ring-blue-500"></textarea>
                </div>

                <!-- Test Requirements -->
                <div class="space-y-2 md:col-span-2">
                    <label class="block text-sm font-medium text-blue-600">Test Requirements</label>
                    <textarea name="requirements" rows="2" class="block w-full rounded-md border-blue-200 shadow-sm focus:border-blue-500 focus:ring-blue-500" placeholder="e.g. Fasting required, Bring previous reports"></textarea>
                </div>
            </div>

            <!-- Form Footer -->
            <div class="mt-8 flex justify-end space-x-3">
                <a href="<?php echo e(route('admin.lab-tests.index')); ?>" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    Cancel
                </a>
                <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    Save Lab Test
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP\hospital-lab-system\resources\views/admin/lab_tests/create.blade.php ENDPATH**/ ?>