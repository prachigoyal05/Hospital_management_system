

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Staff Dashboard</h1>
    <p>Welcome, <?php echo e(Auth::user()->name); ?> (Staff)</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP\hospital-lab-system\resources\views/staff/dashboard.blade.php ENDPATH**/ ?>