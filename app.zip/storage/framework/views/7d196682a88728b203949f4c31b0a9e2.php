

<?php $__env->startSection('content'); ?>
    <div class="mb-6">
        <h1 class="text-2xl font-semibold mb-4">Patients</h1>
        <a href="<?php echo e(route('admin.patients.create')); ?>" class="px-4 py-2 bg-blue-500 text-blue rounded">Add Patient</a>
    </div>



    <?php if(session('success')): ?>
        <div class="mb-4 text-green-600"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
       <table class="w-full table-fixed border bg-white rounded">
    <thead>
        <tr class="bg-gray-200">
            <th class="p-2 text-left w-1/6">Name</th>
            <th class="p-2 text-left w-1/6">Email</th>
            <th class="p-2 text-left w-1/6">Phone</th>
            <th class="p-2 text-left w-1/6">Date of birth</th>
            <th class="p-2 text-left w-1/6">Address</th>
            <th class="p-2 text-left w-1/6">Actions</th>
        </tr>
    </thead>

    
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="p-2"><?php echo e($patient->name); ?></td>
                    <td class="p-2"><?php echo e($patient->email); ?></td>
                    <td class="p-2"><?php echo e($patient->phone); ?></td>
                    <td class="p-2"><?php echo e($patient->dob); ?></td>
                    <td class="p-2"><?php echo e($patient->address); ?></td>
                    <td class="p-2">
                        <a href="<?php echo e(route('admin.patients.edit', $patient)); ?>" class="text-blue-500">Edit</a> |
                        <form action="<?php echo e(route('admin.patients.destroy', $patient)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-500" onclick="return confirm('Delete this patient?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6"class="p-4 text-center">No patients found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>


    
    <div class="mt-4">
       <?php if($patients->hasPages()): ?>
    <div class="flex justify-between items-center mt-4">
        <?php if($patients->onFirstPage()): ?>
            <span class="px-4 py-2 border rounded text-gray-400">&laquo; Previous</span>
        <?php else: ?>
            <a href="<?php echo e($patients->previousPageUrl()); ?>" class="px-4 py-2 border rounded text-blue-600 hover:bg-blue-50">&laquo; Previous</a>
        <?php endif; ?>
        
        <?php if($patients->hasMorePages()): ?>
            <a href="<?php echo e($patients->nextPageUrl()); ?>" class="px-4 py-2 border rounded text-blue-600 hover:bg-blue-50">Next &raquo;</a>
        <?php else: ?>
            <span class="px-4 py-2 border rounded text-gray-400">Next &raquo;</span>
        <?php endif; ?>
    </div>
<?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP\hospital-lab-system\resources\views/admin/patients/index.blade.php ENDPATH**/ ?>