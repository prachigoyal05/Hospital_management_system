<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Patient extends Model
{
   protected $fillable = ['name', 'email', 'phone', 'dob', 'address'];

   public function reports()
{
    return $this->hasMany(Report::class);
}


}
